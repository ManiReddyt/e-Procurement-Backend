﻿namespace EProcurement.Domain.Enums
{
    public enum UserType
    {
        Buyer,
        Bidder,
        Admin
    }
}
