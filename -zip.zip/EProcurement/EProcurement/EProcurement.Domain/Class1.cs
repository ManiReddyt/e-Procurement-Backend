﻿namespace EProcurement.Domain
{
    public class Class1
    {

    }
}