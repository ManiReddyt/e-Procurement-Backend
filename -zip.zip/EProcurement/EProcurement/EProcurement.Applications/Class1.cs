﻿namespace EProcurement.Applications
{
    public class Class1
    {

    }
}