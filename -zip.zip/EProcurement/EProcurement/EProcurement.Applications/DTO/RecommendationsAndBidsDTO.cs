﻿namespace EProcurement.Applications.DTO
{
    public class RecommendationsAndBidsDTO
    {
        public string Name { set; get; }
        public int QuotingPrice { set; get; }
        public int Warrenty { set; get; }
        public int Experience { set; get; }
        public double Rating { set; get; }
    }
}
