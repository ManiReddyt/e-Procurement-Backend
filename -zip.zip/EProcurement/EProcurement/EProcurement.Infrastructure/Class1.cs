﻿namespace EProcurement.Infrastructure
{
    public class Class1
    {

    }
}